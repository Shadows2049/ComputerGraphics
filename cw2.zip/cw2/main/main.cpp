#include<iostream>
#include<glad.h>
#include<GLFW/glfw3.h>
#include"shaderClass.h"
#include<stb_image.h>
#include"Texture.h"
#include"VAO.h"
#include"VBO.h"
#include"EBO.h"
#include <glad.h>
#include <GLFW/glfw3.h>

#include <typeinfo>
#include <stdexcept>

#include <cstdio>
#include <cstdlib>

#include "../support/error.hpp"
#include "../support/program.hpp"
#include "../support/checkpoint.hpp"
#include "../support/debug_output.hpp"

#include "../vmlib/vec4.hpp"
#include "../vmlib/mat44.hpp"

#include "defaults.hpp"

#include"Libraries/include/glm/glm.hpp"
#include"Libraries/include/glm/gtc/matrix_transform.hpp"
#include"Libraries/include/glm/gtc/type_ptr.hpp"

#include"Camera.h"
#include"Mesh.h"
#include<filesystem>
namespace fs = std::filesystem;




const unsigned int width = 1280;
const unsigned int height = 720;
namespace
{
	constexpr char const* kWindowTitle = "COMP3811 - Coursework 2";

	void glfw_callback_error_(int, char const*);

	void glfw_callback_key_(GLFWwindow*, int, int, int, int);

	struct GLFWCleanupHelper
	{
		~GLFWCleanupHelper();
	};
	struct GLFWWindowDeleter
	{
		~GLFWWindowDeleter();
		GLFWwindow* window;
	};
}


// Vertices coordinates Pyramid
Vertex vertices[] =
{ //     COORDINATES     /        COLORS          /    TexCoord   /        NORMALS       //
	Vertex{glm::vec3(-0.5f, 0.0f,  0.5f),     glm::vec3(0.83f, 0.70f, 0.44f), 	 glm::vec3(0.0f, -1.0f, 0.0f), glm::vec2(0.0f, 0.0f)}, // Bottom side
	Vertex{glm::vec3(-0.5f, 0.0f, -0.5f),     glm::vec3(0.83f, 0.70f, 0.44f),	 glm::vec3(0.0f, -1.0f, 0.0f), glm::vec2(0.0f, 5.0f)}, // Bottom side
	 Vertex{glm::vec3(0.5f, 0.0f, -0.5f),     glm::vec3(0.83f, 0.70f, 0.44f),	 glm::vec3(0.0f, -1.0f, 0.0f), glm::vec2(5.0f, 5.0f)}, // Bottom side
	 Vertex{glm::vec3(0.5f, 0.0f,  0.5f),     glm::vec3(0.83f, 0.70f, 0.44f),	 glm::vec3(0.0f, -1.0f, 0.0f), glm::vec2(5.0f, 0.0f)}, // Bottom side

	Vertex{glm::vec3(-0.5f, 0.0f,  0.5f),     glm::vec3(0.83f, 0.70f, 0.44f), 	 glm::vec3(-0.8f, 0.5f,  0.0f), glm::vec2(0.0f, 0.0f)}, // Left Side
	Vertex{glm::vec3(-0.5f, 0.0f, -0.5f),     glm::vec3(0.83f, 0.70f, 0.44f),	 glm::vec3(-0.8f, 0.5f,  0.0f), glm::vec2(5.0f, 0.0f)}, // Left Side
	Vertex{glm::vec3(0.0f, 0.8f,  0.0f),     glm::vec3(0.92f, 0.86f, 0.76f),	 glm::vec3(-0.8f, 0.5f,  0.0f), glm::vec2(2.5f, 5.0f)}, // Left Side

	Vertex{glm::vec3(-0.5f, 0.0f, -0.5f),     glm::vec3(0.83f, 0.70f, 0.44f),	 glm::vec3(0.0f, 0.5f, -0.8f), glm::vec2(5.0f, 0.0f)}, // Non-facing side
	 Vertex{glm::vec3(0.5f, 0.0f, -0.5f),     glm::vec3(0.83f, 0.70f, 0.44f),	 glm::vec3(0.0f, 0.5f, -0.8f), glm::vec2(0.0f, 0.0f)}, // Non-facing side
	 Vertex{glm::vec3(0.0f, 0.8f,  0.0f),     glm::vec3(0.92f, 0.86f, 0.76f),	 glm::vec3(0.0f, 0.5f, -0.8f), glm::vec2(2.5f, 5.0f)}, // Non-facing side

	 Vertex{glm::vec3(0.5f, 0.0f, -0.5f),     glm::vec3(0.83f, 0.70f, 0.44f),	 glm::vec3(0.8f, 0.5f,  0.0f), glm::vec2(0.0f, 0.0f)}, // Right side
	Vertex{ glm::vec3(0.5f, 0.0f,  0.5f),     glm::vec3(0.83f, 0.70f, 0.44f),	 glm::vec3(0.8f, 0.5f,  0.0f), glm::vec2(5.0f, 0.0f)}, // Right side
	 Vertex{glm::vec3(0.0f, 0.8f,  0.0f),     glm::vec3(0.92f, 0.86f, 0.76f),	 glm::vec3(0.8f, 0.5f,  0.0f), glm::vec2(2.5f, 5.0f)}, // Right side

	Vertex{ glm::vec3(0.5f, 0.0f,  0.5f),     glm::vec3(0.83f, 0.70f, 0.44f),	 glm::vec3(0.0f, 0.5f,  0.8f), glm::vec2(5.0f, 0.0f)}, // Facing side
	Vertex{glm::vec3(-0.5f, 0.0f,  0.5f),     glm::vec3(0.83f, 0.70f, 0.44f), 	 glm::vec3(0.0f, 0.5f,  0.8f), glm::vec2(0.0f, 0.0f)}, // Facing side
	Vertex{ glm::vec3(0.0f, 0.8f,  0.0f),     glm::vec3(0.92f, 0.86f, 0.76f),	 glm::vec3(0.0f, 0.5f,  0.8f), glm::vec2(2.5f, 5.0f)}  // Facing side
};

// Indices for vertices order
GLuint indices[] =
{
	0, 1, 2, // Bottom side
	0, 2, 3, // Bottom side
	4, 6, 5, // Left side
	7, 9, 8, // Non-facing side
	10, 12, 11, // Right side
	13, 15, 14 // Facing side
};


// Vertices coordinates
Vertex vertices1[] =
{ //               COORDINATES           /            COLORS          /           TexCoord         /       NORMALS         //
	Vertex{glm::vec3(-15.0f, 0.0f,  15.0f), glm::vec3(0.0f, 1.0f, 0.0f), glm::vec3(1.0f, 1.0f, 1.0f), glm::vec2(0.0f, 0.0f)},
	Vertex{glm::vec3(-15.0f, 0.0f, -15.0f), glm::vec3(0.0f, 1.0f, 0.0f), glm::vec3(1.0f, 1.0f, 1.0f), glm::vec2(0.0f, 1.0f)},
	Vertex{glm::vec3(15.0f, 0.0f, -15.0f), glm::vec3(0.0f, 1.0f, 0.0f), glm::vec3(1.0f, 1.0f, 1.0f), glm::vec2(1.0f, 1.0f)},
	Vertex{glm::vec3(15.0f, 0.0f,  15.0f), glm::vec3(0.0f, 1.0f, 0.0f), glm::vec3(1.0f, 1.0f, 1.0f), glm::vec2(1.0f, 0.0f)}
};
// Indices for vertices order
GLuint indices1[] =
{
	0, 1, 2,
	0, 2, 3
};




// Vertices coordinates Pyramid
Vertex vertices2[] =
{ //     COORDINATES     /        COLORS          /    TexCoord   /        NORMALS       //
	Vertex{glm::vec3(-0.5f, 0.0f,  0.5f),     glm::vec3(0.83f, 0.70f, 0.44f), 	 glm::vec3(0.0f, -1.0f, 0.0f), glm::vec2(0.0f, 0.0f)}, // Bottom side
	Vertex{glm::vec3(-0.5f, 0.0f, -0.5f),     glm::vec3(0.83f, 0.70f, 0.44f),	 glm::vec3(0.0f, -1.0f, 0.0f), glm::vec2(0.0f, 5.0f)}, // Bottom side
	 Vertex{glm::vec3(0.5f, 0.0f, -0.5f),     glm::vec3(0.83f, 0.70f, 0.44f),	 glm::vec3(0.0f, -1.0f, 0.0f), glm::vec2(5.0f, 5.0f)}, // Bottom side
	 Vertex{glm::vec3(0.5f, 0.0f,  0.5f),     glm::vec3(0.83f, 0.70f, 0.44f),	 glm::vec3(0.0f, -1.0f, 0.0f), glm::vec2(5.0f, 0.0f)}, // Bottom side

	Vertex{glm::vec3(-0.5f, 0.0f,  0.5f),     glm::vec3(0.83f, 0.70f, 0.44f), 	 glm::vec3(-0.8f, 0.5f,  0.0f), glm::vec2(0.0f, 0.0f)}, // Left Side
	Vertex{glm::vec3(-0.5f, 0.0f, -0.5f),     glm::vec3(0.83f, 0.70f, 0.44f),	 glm::vec3(-0.8f, 0.5f,  0.0f), glm::vec2(5.0f, 0.0f)}, // Left Side
	Vertex{glm::vec3(0.0f, 0.8f,  0.0f),     glm::vec3(0.92f, 0.86f, 0.76f),	 glm::vec3(-0.8f, 0.5f,  0.0f), glm::vec2(2.5f, 5.0f)}, // Left Side

	Vertex{glm::vec3(-0.5f, 0.0f, -0.5f),     glm::vec3(0.83f, 0.70f, 0.44f),	 glm::vec3(0.0f, 0.5f, -0.8f), glm::vec2(5.0f, 0.0f)}, // Non-facing side
	 Vertex{glm::vec3(0.5f, 0.0f, -0.5f),     glm::vec3(0.83f, 0.70f, 0.44f),	 glm::vec3(0.0f, 0.5f, -0.8f), glm::vec2(0.0f, 0.0f)}, // Non-facing side
	 Vertex{glm::vec3(0.0f, 0.8f,  0.0f),     glm::vec3(0.92f, 0.86f, 0.76f),	 glm::vec3(0.0f, 0.5f, -0.8f), glm::vec2(2.5f, 5.0f)}, // Non-facing side

	 Vertex{glm::vec3(0.5f, 0.0f, -0.5f),     glm::vec3(0.83f, 0.70f, 0.44f),	 glm::vec3(0.8f, 0.5f,  0.0f), glm::vec2(0.0f, 0.0f)}, // Right side
	Vertex{ glm::vec3(0.5f, 0.0f,  0.5f),     glm::vec3(0.83f, 0.70f, 0.44f),	 glm::vec3(0.8f, 0.5f,  0.0f), glm::vec2(5.0f, 0.0f)}, // Right side
	 Vertex{glm::vec3(0.0f, 0.8f,  0.0f),     glm::vec3(0.92f, 0.86f, 0.76f),	 glm::vec3(0.8f, 0.5f,  0.0f), glm::vec2(2.5f, 5.0f)}, // Right side

	Vertex{ glm::vec3(0.5f, 0.0f,  0.5f),     glm::vec3(0.83f, 0.70f, 0.44f),	 glm::vec3(0.0f, 0.5f,  0.8f), glm::vec2(5.0f, 0.0f)}, // Facing side
	Vertex{glm::vec3(-0.5f, 0.0f,  0.5f),     glm::vec3(0.83f, 0.70f, 0.44f), 	 glm::vec3(0.0f, 0.5f,  0.8f), glm::vec2(0.0f, 0.0f)}, // Facing side
	Vertex{ glm::vec3(0.0f, 0.8f,  0.0f),     glm::vec3(0.92f, 0.86f, 0.76f),	 glm::vec3(0.0f, 0.5f,  0.8f), glm::vec2(2.5f, 5.0f)}  // Facing side
};

// Indices for vertices order
GLuint indices2[] =
{
	0, 1, 2, // Bottom side
	0, 2, 3, // Bottom side
	4, 6, 5, // Left side
	7, 9, 8, // Non-facing side
	10, 12, 11, // Right side
	13, 15, 14 // Facing side
};






Vertex lightVertices[] =
{ //     COORDINATES     //
	Vertex{glm::vec3(-0.1f, -0.1f,  0.1f)},
	Vertex{glm::vec3(-0.1f, -0.1f, -0.1f)},
	Vertex{glm::vec3(0.1f, -0.1f, -0.1f)},
	Vertex{glm::vec3(0.1f, -0.1f,  0.1f)},
	Vertex{glm::vec3(-0.1f,  0.1f,  0.1f)},
	Vertex{glm::vec3(-0.1f,  0.1f, -0.1f)},
	Vertex{glm::vec3(0.1f,  0.1f, -0.1f)},
	Vertex{glm::vec3(0.1f,  0.1f,  0.1f)}
};


GLuint lightIndices[] =
{
	0, 1, 2,
	0, 2, 3,
	0, 4, 7,
	0, 7, 3,
	3, 7, 6,
	3, 6, 2,
	2, 6, 5,
	2, 5, 1,
	1, 5, 4,
	1, 4, 0,
	4, 5, 6,
	4, 6, 7
};

Vertex lightVertices2[] =
{ //     COORDINATES     //
	Vertex{glm::vec3(-0.1f, -0.1f,  0.1f)},
	Vertex{glm::vec3(-0.1f, -0.1f, -0.1f)},
	Vertex{glm::vec3(0.1f, -0.1f, -0.1f)},
	Vertex{glm::vec3(0.1f, -0.1f,  0.1f)},
	Vertex{glm::vec3(-0.1f,  0.1f,  0.1f)},
	Vertex{glm::vec3(-0.1f,  0.1f, -0.1f)},
	Vertex{glm::vec3(0.1f,  0.1f, -0.1f)},
	Vertex{glm::vec3(0.1f,  0.1f,  0.1f)}
};


GLuint lightIndices2[] =
{
	0, 1, 2,
	0, 2, 3,
	0, 4, 7,
	0, 7, 3,
	3, 7, 6,
	3, 6, 2,
	2, 6, 5,
	2, 5, 1,
	1, 5, 4,
	1, 4, 0,
	4, 5, 6,
	4, 6, 7
};


int main() try
{
	// Initialize GLFW
	if (GLFW_TRUE != glfwInit())
	{
		char const* msg = nullptr;
		int ecode = glfwGetError(&msg);
		throw Error("glfwInit() failed with '%s' (%d)", msg, ecode);
	}

	// Ensure that we call glfwTerminate() at the end of the program.
	GLFWCleanupHelper cleanupHelper;

	// Configure GLFW and create window
	glfwSetErrorCallback(&glfw_callback_error_);

	glfwWindowHint(GLFW_SRGB_CAPABLE, GLFW_TRUE);
	glfwWindowHint(GLFW_DOUBLEBUFFER, GLFW_TRUE);

	//glfwWindowHint( GLFW_RESIZABLE, GLFW_FALSE );

	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GLFW_TRUE);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	glfwWindowHint(GLFW_DEPTH_BITS, 24);

#	if !defined(NDEBUG)
	// When building in debug mode, request an OpenGL debug context. This
	// enables additional debugging features. However, this can carry extra
	// overheads. We therefore do not do this for release builds.
	glfwWindowHint(GLFW_OPENGL_DEBUG_CONTEXT, GLFW_TRUE);
#	endif // ~ !NDEBUG

	GLFWwindow* window = glfwCreateWindow(
		width,
		height,
		kWindowTitle,
		nullptr, nullptr
	);

	if (!window)
	{
		char const* msg = nullptr;
		int ecode = glfwGetError(&msg);
		throw Error("glfwCreateWindow() failed with '%s' (%d)", msg, ecode);
	}

	GLFWWindowDeleter windowDeleter{ window };

	// Set up event handling
	glfwSetKeyCallback(window, &glfw_callback_key_);

	// Set up drawing stuff
	glfwMakeContextCurrent(window);
	glfwSwapInterval(1); // V-Sync is on.

	// Initialize GLAD
	// This will load the OpenGL API. We mustn't make any OpenGL calls before this!
	if (!gladLoadGLLoader((GLADloadproc)&glfwGetProcAddress))
		throw Error("gladLoaDGLLoader() failed - cannot load GL API!");

	std::printf("RENDERER %s\n", glGetString(GL_RENDERER));
	std::printf("VENDOR %s\n", glGetString(GL_VENDOR));
	std::printf("VERSION %s\n", glGetString(GL_VERSION));
	std::printf("SHADING_LANGUAGE_VERSION %s\n", glGetString(GL_SHADING_LANGUAGE_VERSION));

	// Ddebug output
#	if !defined(NDEBUG)
	setup_gl_debug_output();
#	endif // ~ !NDEBUG

	// Global GL state
	OGL_CHECKPOINT_ALWAYS();

	// TODO: global GL setup goes here
	OGL_CHECKPOINT_ALWAYS();
	glViewport(0, 0, width, height);


	std::string parentDir = (fs::current_path().fs::path::parent_path()).string();
	std::string texPath = "assets/textures/";



	Texture textures[]
	{
		Texture((texPath + "planks.png").c_str(), "diffuse", 0, GL_RGBA, GL_UNSIGNED_BYTE),
		Texture((texPath + "planksSpec.png").c_str(), "specular", 1, GL_RED, GL_UNSIGNED_BYTE)
	};
	Texture textures0[]
	{
		Texture((texPath + "brick.png").c_str(), "diffuse", 0, GL_RGBA, GL_UNSIGNED_BYTE)
	};
	Texture textures1[]
	{
		Texture((texPath + "Chongshou.png").c_str(), "diffuse", 0, GL_RGBA, GL_UNSIGNED_BYTE)
	};
	Texture textures2[]
	{
		Texture((texPath + "popCat.png").c_str(), "diffuse", 0, GL_RGBA, GL_UNSIGNED_BYTE)
	};



	//Pyramid1
	// Generates Shader object using shaders defualt.vert and default.frag
	Shader shaderProgram("main/default.vert", "main/default.frag");

	std::vector <Vertex> vertsP(vertices, vertices + sizeof(vertices) / sizeof(Vertex));
	std::vector <GLuint> indP(indices, indices + sizeof(indices) / sizeof(GLuint));
	std::vector <Texture> texP(textures0, textures0 + sizeof(textures0) / sizeof(Texture));
	// Create pyramid mesh
	Mesh pyramid(vertsP, indP, texP);

	//Pyramid2
	// Generates Shader object using shaders defualt.vert and default.frag
	Shader shaderProgram2("main/default.vert", "main/defaultS.frag");

	std::vector <Vertex> vertsP2(vertices, vertices + sizeof(vertices) / sizeof(Vertex));
	std::vector <GLuint> indP2(indices, indices + sizeof(indices) / sizeof(GLuint));
	std::vector <Texture> texP2(textures2, textures2 + sizeof(textures2) / sizeof(Texture));
	// Create pyramid mesh
	Mesh pyramid2(vertsP2, indP2, texP2);

	//Pyramid3
	// Generates Shader object using shaders defualt.vert and default.frag
	Shader shaderProgram3("main/default.vert", "main/defaultS.frag");

	std::vector <Vertex> vertsP3(vertices, vertices + sizeof(vertices) / sizeof(Vertex));
	std::vector <GLuint> indP3(indices, indices + sizeof(indices) / sizeof(GLuint));
	std::vector <Texture> texP3(textures0, textures0 + sizeof(textures0) / sizeof(Texture));
	// Create pyramid mesh
	Mesh pyramid3(vertsP3, indP3, texP3);


	//Pyramid4
	// Generates Shader object using shaders defualt.vert and default.frag
	Shader shaderProgram4("main/default.vert", "main/defaultS.frag");

	std::vector <Vertex> vertsP4(vertices, vertices + sizeof(vertices) / sizeof(Vertex));
	std::vector <GLuint> indP4(indices, indices + sizeof(indices) / sizeof(GLuint));
	std::vector <Texture> texP4(textures1, textures1 + sizeof(textures1) / sizeof(Texture));
	// Create pyramid mesh
	Mesh pyramid4(vertsP4, indP4, texP4);




	//Plank floor
	// Generates Shader object using shaders defualt.vert and default.frag
	Shader shaderProgramPlank("main/default.vert", "main/default.frag");

	std::vector <Vertex> verts(vertices1, vertices1 + sizeof(vertices1) / sizeof(Vertex));
	std::vector <GLuint> ind(indices1, indices1 + sizeof(indices1) / sizeof(GLuint));
	std::vector <Texture> tex(textures, textures + sizeof(textures) / sizeof(Texture));
	// Create floor mesh
	Mesh floor(verts, ind, tex);












	// Shader for light cube
	Shader lightShader("main/light.vert", "main/light.frag");
	// Store mesh data in vectors for the mesh
	std::vector <Vertex> lightVerts(lightVertices, lightVertices + sizeof(lightVertices) / sizeof(Vertex));
	std::vector <GLuint> lightInd(lightIndices, lightIndices + sizeof(lightIndices) / sizeof(GLuint));
	// Crate light mesh
	Mesh light(lightVerts, lightInd, tex);

	// Shader for light cube
	Shader lightShader2("main/light.vert", "main/light.frag");
	// Store mesh data in vectors for the mesh
	std::vector <Vertex> lightVerts2(lightVertices, lightVertices + sizeof(lightVertices) / sizeof(Vertex));
	std::vector <GLuint> lightInd2(lightIndices, lightIndices + sizeof(lightIndices) / sizeof(GLuint));
	// Crate light mesh
	Mesh light2(lightVerts2, lightInd2, tex);

	// Shader for light cube
	Shader lightShader3("main/light.vert", "main/light.frag");
	// Store mesh data in vectors for the mesh
	std::vector <Vertex> lightVerts3(lightVertices2, lightVertices2 + sizeof(lightVertices2) / sizeof(Vertex));
	std::vector <GLuint> lightInd3(lightIndices2, lightIndices2 + sizeof(lightIndices2) / sizeof(GLuint));
	// Crate light mesh
	Mesh light3(lightVerts3, lightInd3, tex);





	glm::vec4 lightColor = glm::vec4(1.0f, 1.0f, 1.0f, 1.0f);
	glm::vec3 lightPos = glm::vec3(0.5f, 0.5f, 0.5f);
	glm::mat4 lightModel = glm::mat4(2.0f);
	lightModel = glm::translate(lightModel, lightPos);

	glm::vec4 lightColor2 = glm::vec4(5.0f, 1.0f, 1.0f, 1.0f);
	glm::vec3 lightPos2 = glm::vec3(2.5f, 1.5f, -1.0f);
	glm::mat4 lightModel2 = glm::mat4(1.0f);
	lightModel2 = glm::translate(lightModel2, lightPos2);
	
	glm::vec4 lightColor3 = glm::vec4(1.5f, 5.0f, 1.0f, 1.0f);
	glm::vec3 lightPos3 = glm::vec3(0.0f, 4.15f, -6.0f);
	glm::mat4 lightModel3 = glm::mat4(1.0f);
	lightModel3 = glm::translate(lightModel3, lightPos3);


	glm::vec3 objectPos = glm::vec3(0.0f, 0.0f, 0.0f);
	glm::mat4 objectModel = glm::mat4(1.0f);
	objectModel = glm::translate(objectModel, objectPos);

	glm::vec3 objectPos1 = glm::vec3(2.0f, 0.0f, -1.0f);
	glm::mat4 objectModel1 = glm::mat4(1.0f);
	objectModel1 = glm::translate(objectModel1, objectPos1);

	glm::vec3 objectPos2 = glm::vec3(6.7f, 0.0f, -1.7f);
	glm::mat4 objectModel2 = glm::mat4(0.50f);
	objectModel2 = glm::translate(objectModel2, objectPos2);

	glm::vec3 objectPos3 = glm::vec3(0.0f, 0.0f, -1.0f);
	glm::mat4 objectModel3 = glm::mat4(8.00f);
	objectModel3 = glm::translate(objectModel3, objectPos3);

	lightShader.Activate();
	glUniformMatrix4fv(glGetUniformLocation(lightShader.ID, "model"), 1, GL_FALSE, glm::value_ptr(lightModel));
	glUniform4f(glGetUniformLocation(lightShader.ID, "lightColor"), lightColor.x, lightColor.y, lightColor.z, lightColor.w);

	lightShader2.Activate();
	glUniformMatrix4fv(glGetUniformLocation(lightShader2.ID, "model"), 1, GL_FALSE, glm::value_ptr(lightModel2));
	glUniform4f(glGetUniformLocation(lightShader2.ID, "lightColor"), lightColor2.x, lightColor2.y, lightColor2.z, lightColor2.w);

	lightShader3.Activate();
	glUniformMatrix4fv(glGetUniformLocation(lightShader3.ID, "model"), 1, GL_FALSE, glm::value_ptr(lightModel3));
	glUniform4f(glGetUniformLocation(lightShader3.ID, "lightColor"), lightColor3.x, lightColor3.y, lightColor3.z, lightColor3.w);

	shaderProgram.Activate();
	glUniformMatrix4fv(glGetUniformLocation(shaderProgram.ID, "model"), 1, GL_FALSE, glm::value_ptr(objectModel));
	glUniform4f(glGetUniformLocation(shaderProgram.ID, "lightColor"), lightColor.x, lightColor.y, lightColor.z, lightColor.w);
	glUniform3f(glGetUniformLocation(shaderProgram.ID, "lightPos"), lightPos.x, lightPos.y, lightPos.z);

	shaderProgram2.Activate();
	glUniformMatrix4fv(glGetUniformLocation(shaderProgram2.ID, "model"), 1, GL_FALSE, glm::value_ptr(objectModel1));
	glUniform4f(glGetUniformLocation(shaderProgram2.ID, "lightColor"), lightColor2.x, lightColor2.y, lightColor2.z, lightColor2.w);
	glUniform3f(glGetUniformLocation(shaderProgram2.ID, "lightPos"), lightPos2.x, lightPos2.y, lightPos2.z);

	shaderProgram3.Activate();
	glUniformMatrix4fv(glGetUniformLocation(shaderProgram3.ID, "model"), 1, GL_FALSE, glm::value_ptr(objectModel2));
	glUniform4f(glGetUniformLocation(shaderProgram3.ID, "lightColor"), lightColor2.x, lightColor2.y, lightColor2.z, lightColor2.w);
	glUniform3f(glGetUniformLocation(shaderProgram3.ID, "lightPos"), lightPos2.x, lightPos2.y, lightPos2.z);

	shaderProgram4.Activate();
	glUniformMatrix4fv(glGetUniformLocation(shaderProgram4.ID, "model"), 1, GL_FALSE, glm::value_ptr(objectModel3));
	glUniform4f(glGetUniformLocation(shaderProgram4.ID, "lightColor"), lightColor3.x, lightColor3.y, lightColor3.z, lightColor3.w);
	glUniform3f(glGetUniformLocation(shaderProgram4.ID, "lightPos"), lightPos3.x, lightPos3.y, lightPos3.z);

	shaderProgramPlank.Activate();
	glUniformMatrix4fv(glGetUniformLocation(shaderProgramPlank.ID, "model"), 1, GL_FALSE, glm::value_ptr(objectModel));
	glUniform4f(glGetUniformLocation(shaderProgramPlank.ID, "lightColor"), lightColor.x, lightColor.y, lightColor.z, lightColor.w);
	glUniform3f(glGetUniformLocation(shaderProgramPlank.ID, "lightPos"), lightPos.x, lightPos.y, lightPos.z);


	// Enables the Depth Buffer
	glEnable(GL_DEPTH_TEST);
	Camera camera(width, height, glm::vec3(0.0f, 0.2f, 2.3f));


	// Other initialization & loading
	OGL_CHECKPOINT_ALWAYS();

	// TODO: 

	OGL_CHECKPOINT_ALWAYS();

	// Main loop
	while (!glfwWindowShouldClose(window))
	{	
		// Specify the color of the background
		glClearColor(0.07f, 0.13f, 0.17f, 1.0f);
		// Clean the back buffer and depth buffer
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		// Handles camera inputs
		camera.Inputs(window);
		// Updates and exports the camera matrix to the Vertex Shader
		camera.updateMatrix(45.0f, 0.1f, 100.0f);

		// Draws different meshes
		pyramid.Draw(shaderProgram, camera);
		pyramid2.Draw(shaderProgram2, camera);
		pyramid3.Draw(shaderProgram3, camera);
		pyramid4.Draw(shaderProgram4, camera);
		floor.Draw(shaderProgramPlank, camera);
		light.Draw(lightShader, camera);
		light2.Draw(lightShader2, camera);
		light3.Draw(lightShader3, camera);

		
		// Swap the back buffer with the front buffer
		glfwSwapBuffers(window);
		// Take care of all GLFW events
		glfwPollEvents();
		// Check if window was resized.
		float fbwidth, fbheight;
		{
			int nwidth, nheight;
			glfwGetFramebufferSize(window, &nwidth, &nheight);

			fbwidth = float(nwidth);
			fbheight = float(nheight);

			if (0 == nwidth || 0 == nheight)
			{
				// Window minimized? Pause until it is unminimized.
				// This is a bit of a hack.
				do
				{
					glfwWaitEvents();
					glfwGetFramebufferSize(window, &nwidth, &nheight);
				} while (0 == nwidth || 0 == nheight);
			}

			glViewport(0, 0, nwidth, nheight);
		}

		// Update state

		//TODO: update state

		// Draw scene
		OGL_CHECKPOINT_DEBUG();

		//TODO: draw frame

		OGL_CHECKPOINT_DEBUG();


	}

	// Delete all the objects we've created

	shaderProgram.Delete();
	shaderProgram2.Delete();
	shaderProgram3.Delete();
	shaderProgram4.Delete();
	shaderProgramPlank.Delete();
	lightShader.Delete();
	lightShader2.Delete();
	lightShader3.Delete();
	// Delete window before ending the program
	glfwDestroyWindow(window);
	// Terminate GLFW before ending the program
	glfwTerminate();
	return 0;
}
catch (std::exception const& eErr)
{
	std::fprintf(stderr, "Top-level Exception (%s):\n", typeid(eErr).name());
	std::fprintf(stderr, "%s\n", eErr.what());
	std::fprintf(stderr, "Bye.\n");
	return 1;
}


namespace
{
	void glfw_callback_error_(int aErrNum, char const* aErrDesc)
	{
		std::fprintf(stderr, "GLFW error: %s (%d)\n", aErrDesc, aErrNum);
	}

	void glfw_callback_key_(GLFWwindow* aWindow, int aKey, int, int aAction, int)
	{
		if (GLFW_KEY_ESCAPE == aKey && GLFW_PRESS == aAction)
		{
			glfwSetWindowShouldClose(aWindow, GLFW_TRUE);
			return;
		}
	}
}

namespace
{
	GLFWCleanupHelper::~GLFWCleanupHelper()
	{
		glfwTerminate();
	}

	GLFWWindowDeleter::~GLFWWindowDeleter()
	{
		if (window)
			glfwDestroyWindow(window);
	}
}