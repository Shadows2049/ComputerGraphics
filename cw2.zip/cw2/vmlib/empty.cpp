// This file is intentially left empty. 
//
// Visual Studio does not like static libraries without any sources. This
// file ensures that the is at least one source file in the Visual Studio
// project. This keeps VS happy.

#include "vec2.hpp"
#include "vec4.hpp"

#include "mat22.hpp"
#include "mat44.hpp"
